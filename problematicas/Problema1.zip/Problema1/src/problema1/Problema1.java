/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema1;

import java.util.Scanner;
import java.util.Locale;

public class Problema1 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        entrada.useLocale(Locale.US);

        //Variables
        String nombre;
        String posicion;
        int edad;
        double estatura;
        String mensaje = "";
        boolean bandera = true;
        String opcion;
        double promedioedad = 0;
        int promedioestatura = 0;
        double promedio1;
        double promedio2;
        double contador = 0;
        String guion = "-";
        String formato1 = "edad";
        String formato2 = "estatura";
        //Proceso
        do {
            System.out.println("Ingrese nombre del jugador");
            nombre = entrada.nextLine();
            System.out.println("Ingrese la posicion de juego del jugador");
            posicion = entrada.nextLine();
            System.out.println("Ingrese la edad del jugador");
            edad = entrada.nextInt();
            System.out.println("Ingrese la estatura del jugador");
            estatura = entrada.nextDouble();
            entrada.nextLine();

            System.out.println("Ingrese S si quiere salir");
            opcion = entrada.nextLine();
            //1. Alexander Dominguez -Arquero-, edad 32, estatura 1.95
            mensaje = String.format("\n%s\t%s\t%s%s%s\t%s\t%s\t%s\t%s\t", mensaje,
                    nombre, guion, posicion, guion, formato1, edad, formato2,
                    estatura);
            
            System.out.println("Listado de jugadores");
            System.out.println(mensaje);
            promedioestatura = (int) (promedioestatura + estatura);
            promedioedad = promedioedad + edad;
            contador = contador + 1;
            
            System.out.println("EDAD");
            System.out.println(edad);
            
            if (opcion.equals("S")) {
                bandera = false;
            }

        } while (bandera);

        promedioedad = promedioedad / contador;
        promedioestatura = (int) (promedioestatura / contador);
        System.out.printf("\n Promedio de edades \t%s\n", promedioedad);
        System.out.printf("\n Promedio de estatura \t%s\n", promedioestatura);
    }

}
