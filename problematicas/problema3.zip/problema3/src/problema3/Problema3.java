/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema3;

import java.util.Locale;
import java.util.Scanner;

public class Problema3 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        entrada.useLocale(Locale.US);
        int numero=0;
        
        do {
            System.out.println("2");
            System.out.println(2 + 3);
            System.out.println(5*2);
            System.out.println(10+7);
            System.out.println(10+16);
            System.out.println(26+11);
        } while (numero == 1);
    }

}
