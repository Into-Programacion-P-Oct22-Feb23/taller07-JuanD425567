/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema4;

/**
 *
 * @author Cococ
 */
public class Problema4 {

    public static void main(String[] args) {
        int numero = 1;
        System.out.println("1 - 1/3 + 1/5 - 1/7 + 1/9 - 1/11 + 1/13 - 1/15");
        System.out.println(1 - 1/3 + 1/5 - 1/7 + 1/9 - 1/11 + 1/13 - 1/15
);
    }

}
