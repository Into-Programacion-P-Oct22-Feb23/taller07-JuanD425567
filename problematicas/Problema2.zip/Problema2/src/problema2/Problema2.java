//2
//6
//12
//20
//30
//42
//56
//72
//90
//110

package problema2;
import java.util.Locale;
import java.util.Scanner;

public class Problema2 {

  
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        entrada.useLocale(Locale.US);
        //variables
        int numero = 0;
        
        //proceso
     do{
         System.out.println("2");
         System.out.println(2+4);
         System.out.println(6+6);
         System.out.println(12+8);
         System.out.println(20+10);
         System.out.println(30+12);
         System.out.println(42+14);
         System.out.println(56+16);
         System.out.println(72+18);
         System.out.println(90+20);
     }while(numero == 1);
    }
    
}
